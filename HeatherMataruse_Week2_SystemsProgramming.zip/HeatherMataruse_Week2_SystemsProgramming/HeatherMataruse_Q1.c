// Author Heather Mataruse

#include <stdio.h>
#define MAX 100

void
capitalize (char *str, int x)
{
  for (x = 0; str[x] != '\0'; ++x)
    {
      if (x== 0)
	{
	  if ((str[x] >= 'a' && str[x] <= 'z'))
	    str[x] = str[x] - 32;
	  continue;
	}
      if (str[x] == ' ')
	{
	  x++;
	  if (str[x] >= 'a' && str[x] <= 'z')
	    {
	      str[x] = str[x] - 32;
	      continue;
	    }
	}
      else
	{
	  if (str[x] >= 'A' && str[x] <= 'Z')
	    str[x] = str[x] + 32;
	}
    }
  printf ("Word or sentence after Capitalization: %s\n", str);
}

int
main ()
{
  char str[MAX] = { 0 };
  int x;

  printf
    ("\nEnter a word or sentence and I will  Capitalize the first letter of each word __________ ");
  scanf ("%[^\n]s", str);
  printf ("The word/sentence you entered is :  %s\n", str);

  capitalize (str, x);

  return 0;
}
