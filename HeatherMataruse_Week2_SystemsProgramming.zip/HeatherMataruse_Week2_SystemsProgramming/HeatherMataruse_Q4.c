// Author Heather Mataruse

#include<stdio.h>
#include <string.h>

void
count (char *text, int i, int lower_case, int upper_case, int counter)
{
  lower_case = upper_case = counter = 0;

  for (i = 0; text[i] != '\0'; ++i)
    {
      if ((text[i] >= 'A' && text[i] <= 'Z')
	  || (text[i] >= 'a' && text[i] <= 'z'))
	{
	  if ((text[i] >= 'A' && text[i] <= 'Z'))
	    {
	      ++upper_case;
	    }
	  else
	    {
	      ++lower_case;
	    }
	}
      else
	{
	  ++counter;
	}
    }

  printf ("\nThe number of upper case letters are: [ %d ]\n", upper_case);
  printf ("\nThe number of lower case letters are: [ %d ]\n", lower_case);
  printf
    ("\nThe number of special characters(numbers,space,etc) are: [ %d ]\n",
     counter);
}

int
main ()
{
  char text[100];
  int i;
  int lower_case;
  int upper_case;
  int counter;

  printf ("Please enter a string here: ");
  if (fgets (text, sizeof text, stdin) != NULL)
    {

      printf ("\nThe string you entered is: %s\n", text);
    }
  count (text, i, lower_case, upper_case, counter);

  return 0;
}
