// Author Heather


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int
main ()
{

  int random_int = 0, counter = 0, user_input;
  int x;
  long y;

  x = time (NULL);
  y = (unsigned) x / 2;		/*This is the random number generator */
  srand (y);

  random_int = rand () % 100;

  while (1)
    {
      counter += 1;

      printf ("\nGuess a number from (0 - 100): ");
      scanf ("%d", &user_input);

      if (random_int == user_input)
	{
	  printf ("Congratulations, you have guessed a correct number.");
	  printf ("\nYour total amount of tries are: %d", counter);
	  break;
	}
      else if (random_int < user_input)
	{
	  printf ("Generated number is less than entered number, try again");
	}
      else if (random_int > user_input)
	{
	  printf
	    ("Generated number is greater than entered number, try again");
	}

      if (counter == 10)
	{
	  printf ("\n\nYou have used all your 10 attempts\n");
	  break;
	}
    }

  return 0;
}
