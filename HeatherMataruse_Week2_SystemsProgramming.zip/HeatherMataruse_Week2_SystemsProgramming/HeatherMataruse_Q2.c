// Author Heather

#include <stdio.h>
void main(){
  int i,Factorial_x=1,integer_x;

  printf("Enter a number you want to find the Factorial of_______: ");
  scanf("%d",&integer_x);

  for(i=1;i<=integer_x;i++)
     Factorial_x=Factorial_x*i;

  printf("The Factorial of %d is: %d\n",integer_x,Factorial_x);
}