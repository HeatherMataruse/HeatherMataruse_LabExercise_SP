// Author Heather Mataruse
// For this code i faced challenges when i wanted to count the integer the occured the most
// it was oupting the frequency of every integer in the array instead of one number which occurs the most

#include <stdio.h>


int main()
{
int a[10],i,n,largest,smallest;
printf("Enter the number 10 to indicate the number of integers in the array:\n");
scanf("%d",&n);
printf("Please Enter any ten integers of your choice eg (5 ,6 ..)\n");

 
for(i=0;i<n;++i)
scanf("%d",&a[i]);

largest=smallest=a[0];
for(i=1;i<n;++i)
{
if(a[i]>largest)
largest=a[i];
if(a[i]<smallest)
smallest=a[i];
}

printf("Your  largest element  in your  array is %d",largest);
printf("\nYour  smallest element in  your array is %d",smallest);
 
return 0;
}