// Author Heather Mataruse

 #include <stdio.h>
#include <math.h>
int perfectSquare ()
{
    int user_input;
    int integer1;
    float float1;
    // here I am just capturing the user input
    printf("\nEnter a positive integer: \nTo determine if it is a perfect Square:)");
    scanf("%d",&user_input);
    float1 = sqrt((double)user_input);
    // from here am checking if the number the user has entered is  a perfectSquare or not
    integer1 = float1;
    if(integer1 == float1)
    return user_input;
    int user_input_1 = user_input + 1;
    int user_input_2 = user_input - 1;
    if(integer1!=float1){
    printf(" %d is not a perfect square.",user_input);}
    // so if the number is not a perfectSquare the program will find the closest number that is a perfectSquare
    while(user_input_1 <= 9999999){
        int integer_1;
        float float_1;
        float_1 = sqrt((double)user_input_1);
        integer_1 = float_1;
        if(integer_1 != float_1){
           user_input_1 ++;}
        else{
            return user_input_1;
        break;
        }
        int integer_2;
        float float_2;
        float_2 = sqrt((double)user_input_2);
        integer_2 = float_2;
        if(integer_2 != float_2){
            user_input_2 --;}
        else{
            return user_input_2;
        break;
        }
}
}
int
main ()
{
    // here am just calling the perfectSquare function that prints the number
  int perfect_square = perfectSquare();
  printf (" %d is a perfect square.", perfect_square);
}