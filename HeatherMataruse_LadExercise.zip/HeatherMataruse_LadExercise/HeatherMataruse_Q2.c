/  Author Heather Mataruse
// here am just importing libraries
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
int user_input=0;
int sum=0;
int x=0;
printf("Enter any positive large number of your choice: that has 1 to 10 digits eg (456) ");
// here i am just capturing the user_input
scanf("%d", &user_input);
 
    while(user_input > 0)
    {
    x = user_input%10;
   user_input= user_input/10;
    sum = sum + x;
    }

printf("Your sum of the positive integers is  %d\n",sum);
return 0;
}
