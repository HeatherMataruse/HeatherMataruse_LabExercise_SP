// Author Heather Mataruse
#include <stdio.h>
#include <stdlib.h>

void main()
{
    int i;
    // this user input is the integer the user is going to give
    int user_input;
    // so here I am just setting the sum at the beginning as 
    // zero because the user has not given us input yet
    int odd_sum = 0;
    int even_sum = 0;
    int third_sum = 0;
    int fifth_sum = 0;
 
    printf("Welcome to Addition Class  \nEnter a number greater than 0 (eg 3,5,8)\n");
    // here I just capture the input from the user
    scanf("%d", &user_input);
   
    while(user_input<1){
        // this tells the user to put an integer when the user has put a strin
        printf("Re-enter a number greater than 0 \nTry again:"); 
        // this captures the user input
        scanf("%d", &user_input); 
        if(user_input>=1){
            break;
        }
    }
   
    for (i = 1; i <= user_input; i++)
    {
        // here we are checking if the number is even or not that is why we are dividing by 2
        if (i % 2 == 0)
            even_sum = even_sum+ i;
        else
             odd_sum =  odd_sum + i;
    }
   
    int absoluteValue = abs(even_sum -  odd_sum);
   third_sum = even_sum * 1/3;
    fifth_sum =  odd_sum * 1/5;
    printf("Sum of odd numbers  is  %d\n",  odd_sum);
    printf("Sum of  even numbers is %d\n", even_sum);
    printf("Absolute difference bs = %d\n",  absoluteValue);
    printf("Your third sum of the even numbers = %d\n", third_sum);
    printf("Yourbfifth  sum of the odd numbers = %d\n", fifth_sum);
}